#ifndef utilities
#define utilities


/*
 * Author: Nicholas Gardi, 10/3/19
 * header file for the utility functions
 * */


#include "mymv.cpp"
#include "mycp.cpp"
#include "myls.cpp"
#include "mycat.cpp"
#include "myrm.cpp"
#include "mydiff.cpp"
#include "mystat.cpp"

#endif

