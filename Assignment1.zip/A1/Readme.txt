compile fileManager, no special instructions
input below commands into window

mymv:
mymv oldname newname

mycp:
mycp oldname newname

myls:
myls
myls file
myls dir
myls -l file

mycat:
mycat filename1 filename2 ...

myrm:
myrm filename1 filename2 ...

mydiff:
mydiff filename1 filename2

mystat:
mystat file


