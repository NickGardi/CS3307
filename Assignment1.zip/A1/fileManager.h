#ifndef fileManager
#define fileManager
#include <iostream>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <string>
#include <string.h>
#include <vector>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <iterator>
#include <iostream>
#include <fstream>
#include <dirent.h>
#include <stdio.h> 
#include <time.h>
#include <bitset>
#include <sstream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>




/*
 * Author: Nicholas Gardi, 10/3/19
 * header file for fileManager.cpp
 * */

using namespace std;

class File{
private:
    string name;
    int type;
    int size;
    int userID;
    string owner;
    int groupID;
    string group;
    string permissions;
    string accessTime;
    string modTime;
    string statusTime;
    int blockSize;
    vector<File> children;
    int errorNum;
    //vv not sure if right  
    string errorString;
    
public:

    string getName(){return name;}
    void setName(const char* name){Rename(name);}
    int getType(){return type;}
    int getSize(){return size;}
    int getUserID(){return userID;}
    string getOwner(){return owner;}
    int getGroupID(){return groupID;}
    string getGroup(){return group;}
    string getPermissions(){return permissions;}
    string getAccessTime(){return accessTime;}
    string getModTime(){return modTime;}
    string getStatusTime(){return statusTime;}
    int getBlockSize(){return blockSize;}
    vector<File> getChildren(){return children;}
    int getErrorNum(){return errorNum;}
    //string getErrorString(){return errorString;}

    File(string name);
    ~File();
    int Dump(fstream &stream);
    void Rename(const char* newName);
    void Remove();
    bool Compare(File secondFile);	
    int Expand();
   
};

#endif


