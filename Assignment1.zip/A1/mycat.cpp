#include <iostream>
#include <unistd.h>
#include "fileManager.h"
#include <fstream>
/*
 *  Author: Nicholas Gardi, 10/3/19
 * */

//display the contents of all of the files given as parameters
int mycat(vector<string> tokens){
	for (size_t i = 1; i < tokens.size(); i++) { 
		File *file = new File(tokens.at(i));	
		cout << ifstream(file->getName()).rdbuf();
		cout << "" << endl; 
	}
	return 0;
}




