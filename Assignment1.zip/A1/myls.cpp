#include <iostream>
#include "fileManager.h"

/*
 *  Author: Nicholas Gardi, 10/3/19
 * */


//myls when two arguements are given
int myls(string name, string option = "0"){
	File *file = new File(name);	
	if (option.compare("0") == 0){
        //no option given, print files name or directorys contents
		if(file->Expand() == 1){
			//its a directory, print contents
			for (auto& i: file->getChildren()){
				string name = i.getName();
				cout << name << endl;
				return 0;
			}
		}else{
			//its a file, print name
			cout << file->getName() << endl;
			return 0;
		}
    }else if(option.compare("-l") == 0){
       //ls -l file
       cout << "myls -l:" << " ";
	cout << file->getPermissions() << ", owner ID: "; 
	cout << file->getUserID() << ", group: ";
	cout << file->getGroup() << ", block size: ";
	cout << file->getBlockSize() << ", last modified time: ";
	cout << file->getModTime() << ", name of file: ";
	cout << file->getName() << endl;
	return 0;
    }
    return 1;
}

//myls with no file given, print cwd
int myls(){
	char * cwd;
	cwd = (char*) malloc( FILENAME_MAX * sizeof(char) );
	getcwd(cwd,FILENAME_MAX);
	cout << cwd << endl;
	return 0;
}
