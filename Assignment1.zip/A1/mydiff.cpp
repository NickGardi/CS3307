#include <iostream>
#include "fileManager.h"

/*
 *  Author: Nicholas Gardi, 10/3/19
 * */

//returns a boolean value, true if the files are the same, false otherwise
int mydiff(string name1, string name2){
	bool result;
	File *file1 = new File(name1);
	File *file2 = new File(name2);
	result = file1->Compare(*file2);
	if (result)
		cout << "Files are the same" << endl;
	else
		cout << "Files are not the same" << endl;

	return 0;
}
