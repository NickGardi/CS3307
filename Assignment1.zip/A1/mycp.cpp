#include <iostream>
#include "fileManager.h"

/*
 *  Author: Nicholas Gardi, 10/3/19
 * */
 
//Copies a file (not a directory) with name oldname to a new copy newname,
int mycp(string oldName, string newName){
	File *fileSource = new File(oldName);
	File *fileDest = new File(newName);

	filebuf buf;
    buf.open(fileDest->getName().c_str(), ios::out | ios::binary);
    fstream stream(fileDest->getName().c_str(), ios::out |ios::binary);
    fileSource->Dump(stream);
    buf.close();
	cout<< "File successfully copied"<< endl;
    return 0;

		

}

