#include <iostream>
#include "fileManager.h"


/*
 *  Author: Nicholas Gardi, 10/3/19
 * */

//Renames a file or directory from oldName to newName
int mymv(string oldName, string newName){
	
	File *file1 = new File(oldName);
	const char * c = newName.c_str();
	file1->Rename(c);
	return 0;

}

