#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include "fileManager.h"

/*
 *  Author: Nicholas Gardi, 10/3/19
 * */

//prints out the relevant information in a readable format
void mystat(string name){
    File *file = new File(name);
    
    const char *nameChar = file->getName().c_str();
    struct stat info;
    char *perms = (char *) malloc(sizeof(char) * 9 + 1);
    if (stat(nameChar, &info) == 0) {
        mode_t perm = info.st_mode;
        perms[0] = (perm & S_IRUSR) ? 'r' : '-';
        perms[1] = (perm & S_IWUSR) ? 'w' : '-';
        perms[2] = (perm & S_IXUSR) ? 'x' : '-';
        perms[3] = (perm & S_IRGRP) ? 'r' : '-';
        perms[4] = (perm & S_IWGRP) ? 'w' : '-';
        perms[5] = (perm & S_IXGRP) ? 'x' : '-';
        perms[6] = (perm & S_IROTH) ? 'r' : '-';
        perms[7] = (perm & S_IWOTH) ? 'w' : '-';
        perms[8] = (perm & S_IXOTH) ? 'x' : '-';
        perms[9] = '\0';
    }
    
    
	
	cout << "FILE INFO: " << endl;
	cout << "File name: " + file->getName()  << endl;
	cout << "File type: " << "";
	cout << file->getType() << endl;
	cout << "File size: " << "";
	cout << file->getSize() << endl;
	cout << "File userID: " << "";
	cout << file->getUserID() << endl;
	cout << "File owner: " + file->getOwner() << endl;
	cout << "File group ID: " << "";
	cout << file->getGroupID() << endl;
	cout << "File group name: " + file->getGroup() << endl;
	cout << "File permissions: " << "";
	cout << perms << endl;
	cout << "File access time: " + file->getAccessTime() << endl;
	cout << "File last modified time: " + file->getModTime() << endl;   
	cout << "File status time: " + file->getStatusTime() << endl; 
	cout << "File block size: " << "";
	cout <<  file->getBlockSize() << endl;
    
    
    //if file is a directory, print children XX not needed?
    vector<File> children = file->getChildren();
    
    if (!children.empty()){
		cout << "This file is a directory, these are it's contents: " << endl;
		for (auto& i: file->getChildren()){	
			string name = i.getName();
			cout << name << endl;
		}
	}    
    
    
}



   
