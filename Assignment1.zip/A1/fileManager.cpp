#include "fileManager.h"
#include "utilities.h"
/*
 * Author: Nicholas Gardi, 10/3/19
 * this class encapsulates both information pulled from the file system, as well as operations that can be performed on the files.
 * Each instance of File represents one single file/directory
 * */

//constructor, takes name as input then uses stat() to initialize the rest
File::File(string name){
    struct stat info; 
    struct passwd *p;
    struct group *grp;

    
    this->name = name;
    
    const char *nameChar = this->name.c_str();
    if (stat(nameChar, &info) != 0)
    perror("stat() error");
    else {
	this->type = info.st_mode; //fix
	this->size = info.st_size;
	this->userID = info.st_uid;
	
	if ((p = getpwuid(userID)) == NULL){
	    this->owner = "owner string error";
	    perror("getpwuid() error");
	}else{
	    this->owner = p->pw_name;
	}
	this->groupID = info.st_gid;
	
	if ((grp = getgrgid(info.st_gid)) == NULL){
	    this->group = "group string error";
	    perror("getgrgid() error");
	}else{
	    this->group = grp->gr_name;
	}
	
		
	char buffer[10];
	int decimal = info.st_mode & (S_IRWXU | S_IRWXG | S_IRWXO);
	sprintf(buffer, "%o", decimal);	
	this->permissions = buffer;
	
	
	this->accessTime = ctime(&info.st_atime); 
	this->modTime = ctime(&info.st_mtime); 
	this->statusTime = ctime(&info.st_ctime); 
	this->blockSize = info.st_blksize;
	this->errorNum = 0;
    }
}

//destructor, destroys object (not actual file) and frees up space
File::~File(){
    //cout << "File" << this -> name << " destroyed\n"; //need to do more?
}

//take file stream and dump contents of names file to that stream?
int File::Dump(fstream &stream){
    try{
	//regular file
	std::fstream in_file(this->name.c_str(), std::ios::in | std::ios::binary | std::ios::ate);
	size_t size = in_file.tellg();
	char *buffer = new char[size];
	in_file.seekg(0, std::ios::beg);
	in_file.read(buffer, size);
	stream.write(buffer, size);
	in_file.close();
	return 0;
    }catch(exception e){
	errno = ENOTSUP;
        perror("dump(..) error");
    }
    return 1;
}

//takes in a new name and changes the file name
void File::Rename(const char* newName){
    int x;
    
    string oldName = this->name;
    const char *c = oldName.c_str();
    
    x = rename(c, newName);
	
    if(x == 0) {
       printf("File renamed successfully\n");
       this->name = newName;
    } else {
       printf("Error: unable to rename the file\n");
       this->errorNum = 1;//fix this
    }
}

//deletes file object and file in the file system 
void File::Remove(){
    int x;
    
    string name = this->name;
    const char *c = name.c_str();
    x = unlink(c);
	
    if(x == 0) {
       printf("File removed successfully\n");
       delete this;
    } else {
       printf("Error: unable to remove the file\n");
       this->errorNum = 1;//fix this
    }
}


//takes in a second file object, returns Boolean value true if the file contents are the same, otherwise false
bool File::Compare(File secondFile){
    ifstream file1(this->name);
    ifstream file2(secondFile.getName());
    istreambuf_iterator<char> begin1(file1);
    istreambuf_iterator<char> begin2(file2);
    istreambuf_iterator<char> end;
     
    while(begin1 != end && begin2 != end){
	if(*begin1 != *begin2) 
	    return false;
        ++begin1;
        ++begin2;
    }
    return (begin1 == end) && (begin2 == end);
}

//if used on a directory, will create the vector containing the directory's contents, if used on a file, error
int File::Expand(){
    this->name = name;
    const char *nameChar = this->name.c_str();
    DIR *dir;
    struct dirent *ent;
    struct stat s;
    if(stat(nameChar,&s) == 0 ){
	//if object is a directory
	if ((dir = opendir (nameChar)) != NULL) {
	    //create objects for all items in the directory
	    while ((ent = readdir (dir)) != NULL) {
		if ( strcmp(ent->d_name, ".") != 0   &&  strcmp(ent->d_name, "..") != 0){
		    //printf("%s\n", ent->d_name);
		    File *temp = new File(name + "/" + ent->d_name);
		    temp->name = ent->d_name;
		    this->children.push_back(*temp);
		}
	    }
	    return 1;
	    closedir (dir);
	} else {
	    // could not open directory 
	    perror ("");
	    return -1;
	}
    }else{
	//object is not a directory
	return -1;
    }
}    

int main(int argc, char **argv){
    
    
    File *file = new File("file1");	
    fstream stream(file->getName());
    file->Dump(stream);
	
	
	string input;
	while (true){
	    printf("Enter a command or exit: ");
	    getline(cin, input);
	    istringstream buf(input);
	    istream_iterator<string> beg(buf), end;
	    vector<string> tokens(beg, end);
	    
	 
	    string command = tokens.front();
	    
	    
	    if (command.compare("mymv") == 0){
		mymv(tokens.at(1), tokens.at(2)); //good
		tokens.clear();
	    }
	    else if(command.compare("mycp")== 0) {
		mycp(tokens.at(1), tokens.at(2));
		tokens.clear();
	    }
	    else if(command.compare("myls") == 0){
		if(tokens.size() == 1){
		    myls();
		    tokens.clear();
		}
		else if (tokens.size() == 3){
		   myls(tokens.at(2), tokens.at(1));
		   tokens.clear();
		}else{
		   myls(tokens.at(1));
		   tokens.clear();
		}
	    }
	    else if(command.compare("mycat") == 0) { 
		mycat(tokens);
		tokens.clear();
	    }
	    else if(command.compare("myrm") == 0) {
		myrm(tokens);
		tokens.clear();
	    }
	    else if(command.compare("mydiff") == 0) { 
		mydiff(tokens.at(1), tokens.at(2));
	    tokens.clear();
	    }
	    else if(command.compare("mystat") == 0){
		mystat(tokens.at(1));
		tokens.clear();
		}
	    else if(command.compare("exit") == 0){
		cout << "Exiting..." << endl;
		tokens.clear();
		break;
		}
	    }

	return 0;
}




